﻿Заголовок окна
Привет, мир!
c:\Windows\notepad.exe

c:\Windows\notepad.exe

calc.exe

C:\Program Files\Internet Explorer\iexplore.exe
http://simple-scada.com/forum/index.php
excel.exe

winword.exe

UserSound.ogg
МояПапка
actualparams.txt

-1000
CREATE TABLE IF NOT EXISTS `demo_table` (
`ID` INT UNSIGNED NOT NULL AUTO_INCREMENT,
`DateTime` TIMESTAMP,
`Value` REAL,
`Text` CHAR(80),
PRIMARY KEY (`ID`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8;
Wind.txt

Wind.txt

Wind.txt


Средняя температура воздуха
Отчет о СТВ
D:\
192.168.6.7
192.168.6.11
192.168.6.18
192.168.6.19
192.168.6.20
192.168.6.21
192.168.6.22
192.168.6.23
192.168.6.180
192.168.6.201
192.168.6.202
192.168.6.203
192.168.6.206
192.168.6.207
192.168.6.216
192.168.0.101
192.168.0.177
corrector.txt

corrector.txt

pump_changer.txt

pump_changer.txt

actualtplan.txt

http://95.142.45.133:23873/getPumpsInfo11
http://95.142.45.133:23873/getPumpsInfo12
http://95.142.45.133:23873/getPumpsInfo21
http://95.142.45.133:23873/getPumpsInfo22
http://95.142.45.133:23873/getPumpsInfo41
http://95.142.45.133:23873/getPumpsInfo42
1
0
0
1
1
0
0
1
1
0
0
1
1
0
0
1
1
0
0
1
1
0
0
1
